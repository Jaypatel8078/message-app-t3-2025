﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CurrencyConverterPractice
{
    public partial class frmCurrencyConverter : Form
    {

        //private string[,] currency = { { "NZD", "Rupee" }, { "NZD", "USD" }, { "Rupee", "NZD" }, { "Rupee", "USD" }, { "USD", "NZD" }, { "USD", "Rupee" } };
        //2D Array created with 6 rows (1 for each conversion) and 2 columns (1 and the foreign exchange rate)
        //private float[,] currencyValue = { {1, 49.24f }, {1, 0.59f }, {1,0.02f }, {1, 0.012f }, {1, 1.69f }, {1, 83.26f } };
        private float[,] currencyValue;

        public frmCurrencyConverter()
        {
            InitializeComponent();

            //read currency rate from txt file. Formload event in this constructor
            //specify path to txt file
            string[] rates = System.IO.File.ReadAllLines(@"C:\Users\admin\OneDrive - Auckland Institute of Studies\Documents\Subjects\SOFT606 DP\Learning Materials\Week2\Tutorial\CurrencyValues.txt");
            string[] ndx = rates[0].Split(',');
            currencyValue = new float[int.Parse(ndx[0]), int.Parse(ndx[1])];

            for (var i=1; i<rates.Length; i++)
            {
                string[] rate = rates[i].Split(',');
                
                for (var j=0; j<rate.Length;j++) 
                {
                    currencyValue[i-1,j] = float.Parse(rate[j]);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            var unconvertedCurrencyValue = double.Parse(txtAmountToConvert.Text);
            var unconvertedCurrency = cmbConvertFrom.Items[cmbConvertFrom.SelectedIndex];
            var convertedCurrency = cmbConvertTo.Items[cmbConvertTo.SelectedIndex];
            double convertedAmount = 0d;
            var rate = 0f;

            //Rate is set to 1 when converting USD to USD or Rupee to Rupee or NZD to NZD
            if ((cmbConvertFrom.SelectedIndex == 0 && cmbConvertTo.SelectedIndex == 0) ||
                (cmbConvertFrom.SelectedIndex == 1 && cmbConvertTo.SelectedIndex == 1) ||
                (cmbConvertFrom.SelectedIndex == 2 && cmbConvertTo.SelectedIndex == 2))
            {
                rate = 1f;
                convertedAmount = rate * unconvertedCurrencyValue;
            }
            else
            {
                if (cmbConvertFrom.SelectedIndex == 0 && cmbConvertTo.SelectedIndex == 1) //NZD-Rupee
                {
                    rate = currencyValue[0,1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
                else if (cmbConvertFrom.SelectedIndex == 0 && cmbConvertTo.SelectedIndex == 2) //NZD-USD
                {
                    rate = currencyValue[1, 1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
                else if (cmbConvertFrom.SelectedIndex == 1 && cmbConvertTo.SelectedIndex == 0) //Rupee-NZD
                {
                    rate = currencyValue[2, 1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
                else if (cmbConvertFrom.SelectedIndex == 1 && cmbConvertTo.SelectedIndex == 2) //Rupee-USD
                {
                    rate = currencyValue[3, 1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
                else if (cmbConvertFrom.SelectedIndex == 2 && cmbConvertTo.SelectedIndex == 0) //USD-NZD
                {
                    rate = currencyValue[4, 1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
                else if (cmbConvertFrom.SelectedIndex == 2 && cmbConvertTo.SelectedIndex == 1) //USD-Rupee
                {
                    rate = currencyValue[5, 1];
                    convertedAmount = rate * unconvertedCurrencyValue;
                }
            }
                
                txtConvertedAmount.Text = convertedAmount.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath = @"C:\Users\admin\OneDrive - Auckland Institute of Studies\Documents\Subjects\SOFT606 DP\Learning Materials\Week2\Tutorial\output.txt";
                double convertedAmount = double.Parse(txtConvertedAmount.Text);

                // Write the converted amount to the file
                System.IO.File.WriteAllText(filePath, convertedAmount.ToString());

                MessageBox.Show("Data saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
