﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurrencyConverterPractice
{
    public partial class frmCurrencyConverter : Form
    {
       

        public frmCurrencyConverter()
        {
            InitializeComponent();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            var unconvertedCurrencyValue = double.Parse(txtAmountToConvert.Text);
            double convertedAmount = 0;
            var rate = 2.5;


                switch (cmbConvertTo.SelectedIndex) 
            {
                case 0: //NZD or first line from text file and cmb box. they must match
                    convertedAmount = unconvertedCurrencyValue * rate;
                    break; 
                case 1: //Rupee
                    convertedAmount = unconvertedCurrencyValue * (rate +5);
                    break;
                case 2: //USD
                    convertedAmount = unconvertedCurrencyValue * (rate +100);
                    break;
                default:
                    break;
            }
            txtConvertedAmount.Text = convertedAmount.ToString();
        }
    }
}
